package org.tiling.alhambra.gui;

import java.util.EventListener;

public interface TileSelectionListener extends EventListener {
	
	public void valueChanged(TileSelectionEvent event);

}